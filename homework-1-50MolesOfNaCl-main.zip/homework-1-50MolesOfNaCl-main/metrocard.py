fare = 2.75
umc = 127
min = umc/fare

print(min)
print(int(min))
